module.exports = function (grunt) {

    // Project configuration.
    grunt.initConfig({
	pkg: grunt.file.readJSON('package.json'),
	dirs: {
	    src_lib: 'lib'
	},
	bower: {
	    dev: {
		dest: '<%=dirs.src_lib%>',
		js_dest: '<%=dirs.src_lib%>/js',
		css_dest: '<%=dirs.src_lib%>/css',
		map_dest: '<%=dirs.src_lib%>/css',
		less_dest: '<%=dirs.src_lib%>/less',
		fonts_dest: '<%=dirs.src_lib%>/fonts',
		options: {
		    keepExpandedHierarchy: false,
		    packageSpecific: {
			'history.js': {
			    files: [
				'scripts/bundled/html5/jquery.history.js'
			    ]
			},
			bootstrap: {
			    files: [
				'dist/css/*',
				'dist/js/bootstrap.js',
				'dist/fonts/*'
			    ]
			},
			jScrollPane: {
			    files: [
				'script/jquery.jscrollpane.js',
				'script/jquery.mousewheel.js',
				'style/jquery.jscrollpane.css'

			    ]
			},
			leaflet: {
			    files: [
				'dist/leaflet.js',
				'dist/leaflet.css'
			    ]
			},
			'leaflet.markercluster': {
			    files: [
				'dist/leaflet.markercluster.js',
				'dist/MarkerCluster.css'

			    ]
			},
			leafpile: {
			    files: [
				'dist/leafpile.js'
			    ]
			}
		    }
		}
	    }
	},
	copy: {
	    fonts: {
		cwd: 'src/fonts/', // set working folder / root to copy
		src: ['**'], // copy all files and subfolders
		dest: 'dist/fonts', // destination folder
		expand: true           // required when using cwd
	    },
	    img: {
		cwd: 'src/img/', // set working folder / root to copy
		src: ['**'], // copy all files and subfolders
		dest: 'dist/img', // destination folder
		expand: true           // required when using cwd
	    },
	    js: {
		cwd: 'src/js/', // set working folder / root to copy
		src: ['**'], // copy all files and subfolders
		dest: 'dist/js/', // destination folder
		expand: true           // required when using cwd
	    },
	    css: {
		cwd: 'src/css/', // set working folder / root to copy
		src: 'mh5player.custom.css', // copy file
		dest: 'dist/css/', // destination folder
		expand:true
	    },
	    html :{
		cwd: 'src/', // set working folder / root to copy
		src: 'index.html', // copy file
		dest: 'dist/', // destination folder
		expand:true
	    }
	    
	},
	concat: {
	    options: {
		separator: ''
	    },
	    js_lib: {
		src:
			[
			    '<%=dirs.src_lib%>/js/jquery.js',
			    '<%=dirs.src_lib%>/js/jquery.history.js',
			    '<%=dirs.src_lib%>/js/bootstrap.js',
			    '<%=dirs.src_lib%>/js/bootstrap-slider.js',
			    '<%=dirs.src_lib%>/js/knockout.js',
			    '<%=dirs.src_lib%>/js/jquery.jscrollpane.js',
			    '<%=dirs.src_lib%>/js/jquery.mousewheel.js',
			    '<%=dirs.src_lib%>/js/leaflet.js',
			    '<%=dirs.src_lib%>/js/gpx.js',
			    '<%=dirs.src_lib%>/js/leafpile.js',
			    '<%=dirs.src_lib%>/js/leaflet.markercluster.js'
			    //,'src/js/mapmanager.js'
			],
		dest: 'dist/js/lib.bundle.js'
	    },
	    css_lib: {
		src: [
		    '<%=dirs.src_lib%>/css/*.css'
		
		],
		dest: 'dist/css/lib.bundle.css',
		nonull: true
	    },
	       css_custom: {
		src: [
		    'src/css/loader.css',
		    'src/css/jquery.jscrollpane.custom.css',
		    'src/css/main.css'
		],
		dest: 'dist/css/bundle.css',
		nonull: true
	    }

	},
	uglify: {
	    target: {
		files: {
		    'fileadmin/geodaten/js/minified.js': ['fileadmin/geodaten/js/mapmanger.js', 'src/internals.js']
		}
	    }
	}
	
    });

    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-bower');
    grunt.loadNpmTasks('grunt-contrib-concat');

    // Default task(s).
    grunt.registerTask('default', ['copy','uglify', 'bower', 'concat']);

};