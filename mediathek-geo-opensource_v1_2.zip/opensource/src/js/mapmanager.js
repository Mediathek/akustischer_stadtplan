"use strict";
var ajaxUrl = 'http://geo.mediathek.at';
var _gaq = _gaq || [];
var mGeoApp;
(function ($) {

    mGeoApp = {
	config: function () {
	    return config;
	},
	//Player schließen mit bestimmter ID
	closePlayer: function (atomid) {

	    try {

		if (mGeoApp.components.player && mGeoApp.components.player.wrapper)
		{
		    mGeoApp.components.player.wrapper.hide();
		}
	    } catch (e) {
	    }
	    try {
		if (typeof soundManager !== 'undefined' && soundManager) {
		    soundManager.pauseAll();
		}
	    } catch (e) {
		console.log(e);
	    }
	    try {
		if (typeof mh5App !== "undefined" && mh5App && mh5App.wfp) {
		    mh5App.wfp.pause();
		}
	    } catch (e) {
		//console.log(e);
	    }

	},
	//Initialsieren der Karte
	initMap: function (initConfig) {

	    ko.subscribable.fn.subscribeChanged = function (callback) {
		var oldValue;
		this.subscribe(function (_oldValue) {
		    oldValue = _oldValue;
		}, this, 'beforeChange');

		this.subscribe(function (newValue) {
		    callback(newValue, oldValue);
		});
	    };


	    this.tools.isMobile();
	    var confurl = initConfig.url;
	    mGeoApp.mapdata = {};

	    mGeoApp.mapdata.layerGroups = ko.observableArray([]);
	    mGeoApp.mapdata.markers = ko.observableArray([]);

	    var pathname = window.location.pathname;
	    var params = {
		searchurl: pathname
	    }
	    $.when(
		    $.ajax({
			dataType: "json",
			url: confurl,
			data: params
		    })

		    ).done(function (conf)
	    {

		mGeoApp.debugLocal = initConfig.debugLocal;
		mGeoApp.baseurl = conf.config.config.jsBaseUrl;
		mGeoApp.baseurl = "";
		mGeoApp.urls = {
		    "waypoints": {
			"request": conf.config.config.waypointsCall
		    },
		    "search": {
			"request": conf.config.config.searchCall
		    },
		    "walk": {
			"request": conf.config.config.walkCall
		    }
		};
		mGeoApp.config = conf;
		mGeoApp.root = jQuery("#content");
		mGeoApp.mapid = 'map';
		mGeoApp.settings = {};
		mGeoApp.scripts = {};
		mGeoApp.data = {};
		mGeoApp.data.search = {};
		mGeoApp.data.search.Topics = ko.observableArray([]);
		mGeoApp.data.search.PostalCodes = ko.observableArray([]);
		mGeoApp.data.search.Walks = ko.observableArray([]);
		mGeoApp.data.mylocation = ko.observable();

		mGeoApp.components = {};
		mGeoApp.components.search = {};
		mGeoApp.components.search.isVisible = ko.observable(true);
		mGeoApp.components.filter = {};
		mGeoApp.components.filter.isVisible = ko.observable(true);
		mGeoApp.components.filter.navIsHidden = ko.observable(true);


		mGeoApp.components.filterresult = {};
		mGeoApp.components.walks = {};
		mGeoApp.components.walks.isVisible = ko.observable(true);
		mGeoApp.components.map = {};

		mGeoApp.settings.ga = {};
		mGeoApp.settings.ga.track = true;
		mGeoApp.settings.ga.trackingid = ["UA-35955789-19"];

		mGeoApp.loadModules();
		mGeoApp.data.waypoints = ko.observableArray();


		mGeoApp.components.player = {};
		mGeoApp.components.player.isLoaded = false;





		//read initconfig
		if (mGeoApp.config.config.rootElement) {
		    mGeoApp.root = jQuery('#' + mGeoApp.config.config.rootElementID);
		}

		if (mGeoApp.config.config.showSearch) {
		    mGeoApp.components.filter.isVisible(mGeoApp.config.config.showFilter);
		}
		if (mGeoApp.config.config.showFilter) {
		    mGeoApp.components.search.isVisible(mGeoApp.config.config.showSearch);
		}
		if (mGeoApp.config.config.showWalks) {
		    mGeoApp.components.walks.isVisible(mGeoApp.config.config.showWalks);
		}
		// ./ read initconfig






	    });
	},
	//Marker Popup mit bestimmter ID öffnen
	openMarkerPopup: function (id) {
	    if (mGeoApp.mapdata.layerGroups() && mGeoApp.mapdata.layerGroups().length > 0) {
		jQuery.each(mGeoApp.mapdata.markers(), function (key, value) {
		    var markerID = value.options.UID;
		    if (markerID === id) {
			mGeoApp.mapdata.layerGroups()[0].zoomToShowLayer(value, function () {
			    value.openPopup();
			});


		    }
		});
	    }



	},
	//todo
	setWaypoints: function (marker) {
	    mGeoApp.data.waypoints(marker);
	    this.clearLayers();

	    if (marker && marker.length > 0) {
		var markerAudio = L.icon({
		    iconUrl: mGeoApp.baseurl + 'img/marker-audio.png',
		    //shadowUrl: 'leaf-shadow.png',
		    iconSize: [26, 33], // size of the icon
		    shadowSize: [50, 64], // size of the shadow
		    iconAnchor: [13, 33], // point of the icon which will correspond to marker's location
		    shadowAnchor: [4, 62], // the same for the shadow
		    popupAnchor: [0, -33] // point from which the popup should open relative to the iconAnchor
		});
		var markerVideo = L.icon({
		    iconUrl: mGeoApp.baseurl + 'img/marker-video.png',
		    //shadowUrl: 'leaf-shadow.png',
		    iconSize: [26, 33], // size of the icon
		    shadowSize: [50, 64], // size of the shadow
		    iconAnchor: [13, 33], // point of the icon which will correspond to marker's location
		    shadowAnchor: [4, 62], // the same for the shadow
		    popupAnchor: [0, -33] // point from which the popup should open relative to the iconAnchor
		});



		var customMarker = L.Marker.extend({
		    options: {
			UID: ''
		    }
		});
		var mapmarkers = [];

		var markerCluster = L.markerClusterGroup({disableClusteringAtZoom: 18 /*, maxClusterRadius:60*/});


		jQuery.each(mGeoApp.data.waypoints(), function (key, value) {
		    var title = (value.Title.length > 130) ? value.Title.substring(0, 130) + '…' : value.Title;
		    var desc = (value.Description.length > 200) ? value.Description.substring(0, 200) + '…' : value.Description;
		    var b = "";
		    var l = "";

		    var popup = L.popup({maxWidth: 340, minWidth: 340, autoPanPaddingTopLeft: new L.Point(30, 30)})
			    .setContent('<div class="popup" id="popup_' + value.UniqueIdentifier + '" data-atomid="' + value.UniqueIdentifier + '"><div class="popup_title">' + title + '</div><div class="popup_description">' + desc + '</div>\n\
                                     <div class="popup_lower"><div class="popup_image">\n\
                                        <img src="' + mGeoApp.config.config.config.thumbUrl + value.PlacePicture + '"/></div><div class="popup_address">' + value.PlaceStreet + '</div>\n\
                                        <div class="popup_link" ><span class="popup_linkicon"></span><span class="popup_linktext ">Details / Medium abspielen</span></div></div></div>');


		    /*DEBUG
		     * 
		     
		     
		     if (!value){
		     console.log("empty value "+key);
		     
		     
		     }
		     if (value && !value.PlacePositionB){
		     console.log("empty B "+ value);
		     }
		     
		     if (value && !value.PlacePositionL){
		     console.log("empty L "+ value);
		     }
		     */
		    if (value && value.PlacePositionB) {
			b = Number(value.PlacePositionB.replace(",", "."));
		    }
		    if (value && value.PlacePositionL) {
			l = Number(value.PlacePositionL.replace(",", "."));
		    }


		    if (b && l) {
			var myMarker = new customMarker([b, l], {
			    icon: value.Type === "audio" ? markerAudio : markerVideo,
			    UID: value.UniqueIdentifier,
			    title: value.Title
			});
		    }
		    myMarker.bindPopup(popup);

		    /*
		     myMarker.on('click', function(){
		     console.log('marker_click'); 
		     });
		     */
		    mapmarkers.push(myMarker);


		});
		markerCluster.addLayers(mapmarkers);

		mGeoApp.mapdata.markers(mapmarkers);


		/* var layerG = L.featureGroup(mGeoApp.mapdata.markers()).addTo(mGeoApp.components.map);
		 
		 
		 mGeoApp.components.map.fitBounds(layerG.getBounds());
		 mGeoApp.mapdata.layerGroups.push(layerG);
		 */

		//var layerG = L.featureGroup(mGeoApp.mapdata.markers()).addTo(mGeoApp.components.map);


		mGeoApp.components.map.fitBounds(markerCluster.getBounds());
		mGeoApp.mapdata.layerGroups.push(markerCluster);


		if (_gaq) {

		    mGeoApp.components.map.on('popupopen', function (e) {
			var atomid = $(e.popup.getContent()).data("atomid");

			jQuery.each(mGeoApp.settings.ga.trackingid, function (key, value) {

			    _gaq.push(['_setAccount', value]);
			    _gaq.push(['_trackEvent', 'Marker', 'click', atomid]);
			});

		    });
		}



		mGeoApp.components.map.addLayer(markerCluster);



		// The HTML we put in bindPopup doesn't exist yet, so we can't just say
		// $('.popup .popup_link'). Instead, we listen for click events on the map element which
		// will bubble up from the tooltip, once it's created and someone clicks on it.
		$('#map').on('click', '.popup .popup_link, .popup img, .popup .popup_title, .popup .popup_description', function () {
		    var atomid = $(this).closest('.popup').data("atomid");
		    mGeoApp.setPlayer(atomid)
		    //jQuery('.mgeoPlayerwrapper').css('top', '50%');
		    History.pushState({state: "Player", atomid: atomid}, "Atom " + atomid, "?state=" + atomid);

		    jQuery.each(mGeoApp.settings.ga.trackingid, function (key, value) {
			_gaq.push(['_setAccount', value]);
			_gaq.push(['_trackEvent', 'Media', 'show', atomid]);
		    });


		});

	    }

	},
	//Setzt einen Stadtspaziergang
	setGpx: function (url) {
	    if (mGeoApp.mapdata.walk) {
		mGeoApp.components.map.removeLayer(mGeoApp.mapdata.walk);
	    }


	    var gpx = new L.GPX(url + '?' + Date.now(), {
		async: true,
		marker_options: {
		    startIconUrl: '',
		    endIconUrl: '',
		    shadowUrl: mGeoApp.baseurl + 'img/pin-shadow.png'
		},
		polyline_options: {
		    color: '#00335a',
		    lineCap: 'round',
		    weight: 10
		}
	    }).on('loaded', function (e) {
		mGeoApp.components.map.fitBounds(e.target.getBounds());
	    })


	    mGeoApp.mapdata.walk = gpx.addTo(mGeoApp.components.map);

	},
	//Initialisert den HTML5 Player und lädt in gegebenfalls in den DOM falls er dort noch nicht vorhanden ist
	setPlayer: function (atomid) {
	    mGeoApp.tools.showLoader();
	    var desc = "";
	    var descitem = jQuery(".mgeoPlayer-description");
	    descitem.hide();
	    descitem.text("");
	    if (mGeoApp.components.player.isLoaded || mGeoApp.components.player.isLoading) {

		jQuery.each(mGeoApp.data.waypoints(), function (key, value) {
		    if (value.UniqueIdentifier == atomid && value.WayPointDescription)
		    {
			descitem.text(value.WayPointDescription);
			descitem.show();
		    }
		});

		mGeoApp.components.player.config.identifier = atomid;

		if (typeof mh5App != "undefined" && mh5App) {

		    mh5App.resetPlayer(mGeoApp.components.player.config);
		}
		jQuery("mh5playerwrapper").on("mh5AppPlayer:ready", function (event) {

		    mGeoApp.components.player.wrapper.show();
		    mGeoApp.tools.hideLoader();

		});


	    } else {
		mGeoApp.loadPlayer(atomid);
		jQuery("mh5playerwrapper").on("mh5AppPlayer:ready", function (event) {
		    mGeoApp.components.player.wrapper.show();
		    mGeoApp.tools.hideLoader();

		});
	    }



	},
	//Lädt den HTML5 Player in den DOM
	loadPlayer: function (atomid) {
	    mGeoApp.components.player.isLoading = true;

	    $('#content').append('<div class="mgeoPlayerwrapper" style="display:none;"><div class="mgeoPlayer-close"></div><div class="mgeoPlayer-description" style="display:none;"></div><mh5playerwrapper></mh5playerwrapper></div>');

	    mGeoApp.components.player.closeBtn = jQuery('.mgeoPlayer-close');
	    mGeoApp.components.player.wrapper = jQuery('.mgeoPlayerwrapper');


	    var initPlayerConf = {};
	    initPlayerConf.identifier = atomid;
	    initPlayerConf.config = 1;
	    initPlayerConf.sid = "nologin:";
	    initPlayerConf.url = "http://media.mediathek.at/player/config.php";
	    if (location && location != undefined && location.hostname === "geo.web.mbit.at") {
		initPlayerConf.url = "http://geo.web.mbit.at/player/config.php";
	    }



	    initPlayerConf.seekTo = 0;
	    initPlayerConf.seekEnd = 0;
	    initPlayerConf.mediaLength = "0";
	    initPlayerConf.overrideAutoplay = -1;
	    initPlayerConf.morePageRefresh = 0;
	    initPlayerConf.activeTab = "tab2";
	    if (window.location !== window.parent.location) {
		initPlayerConf.config = 2;
	    }

	    mGeoApp.components.player.config = initPlayerConf;





	    mGeoApp.components.player.closeBtn.on("click", function () {
		mGeoApp.closePlayer("");

	    });

	    /*
	     function closePlayer() {
	     mGeoApp.components.player.wrapper.hide();
	     
	     
	     if (mh5App && mh5App.wfp) {
	     mh5App.wfp.pause();
	     
	     }
	     
	     if (soundManager) {
	     soundManager.pauseAll();
	     }
	     
	     }
	     */

	    // Update the page content when the popstate event is called.
	    window.addEventListener('popstate', function (event) {
		//updateContent(event.state)
		//closePlayer();
		mGeoApp.closePlayer("");
	    });


	    var phpurl = "http://media.mediathek.at/player/player.php?identifier=091071A8-169-00021-00000314-090FC364&jsn=1";

	    if (location && location != undefined && location.hostname === "geo.web.mbit.at") {
		phpurl = "http://geo.web.mbit.at/player/player.php?identifier=091071A8-169-00021-00000314-090FC364&jsn=1";
	    }

	    $.when(
		    $.ajax({
			dataType: "json",
			url: phpurl

		    })

		    ).done(function (scripts)
	    {
		var cssfiles = [];
		var jsfiles = [];
		var ignorescripts = ["knockout"];
		jQuery.each(scripts, function (i, item) {
		    var ext = mGeoApp.tools.getFileExtension(item);
		    var curscript = item;
		    jQuery.each(ignorescripts, function (i, toIgnore) {
			if (item.indexOf(toIgnore) > -1) {
			    curscript = "";
			}
		    });
		    if (curscript) {
			if (ext === "css") {
			    cssfiles.push(curscript);
			} else if (ext === "js") {

			    jsfiles.push(curscript);
			}
		    }

		});
		mGeoApp.tools.loadCss(cssfiles);
		mGeoApp.tools.loadCss([mGeoApp.baseurl + "css/mh5player.custom.css?" + Date.now()]);

		mGeoApp.tools.loadScripts(jsfiles, function () {
		    mh5App.initPlayer(initPlayerConf);
		    mGeoApp.components.player.isLoaded = true;
		    mGeoApp.components.player.isLoading = false;
		    mGeoApp.root.trigger("mh5AppPlayer:loaded");
		});
	    }
	    );
	},
	//Lädt die Wegpunktdaten von der definierten URL
	loadWaypoints: function () {
	    $.ajax({
		url: mGeoApp.urls.waypoints.request
	    }).done(function (result) {
		mGeoApp.setWaypoints(result.marker);
	    })

	},
	//Versucht die Geolocation des Nutzers zu finden
	getMyLocation: function () {
	    mGeoApp.components.map.locate({setView: false, maxZoom: 16, watch: true});
	    function onLocationFound(e) {

		mGeoApp.data.mylocation(e);


	    }
	    function onLocationError(e) {
		//console.log(e.message);
	    }

	    mGeoApp.components.map.on('locationerror', onLocationError);


	    mGeoApp.components.map.on('locationfound', onLocationFound);


	},
	//Lädt die einzelen Seitenmodule
	loadModules: function () {
	    //load templatefile
	    $.when(
		    // load your external HTML template
		    $.ajax({
			url: mGeoApp.baseurl + "js/templates/all.html?" + Date.now()

		    })
		    .done(function (templates)
		    {
			var source = $(templates);
			$('body').append('<div style="display:none">' + templates + '<\/div>');
		    })
		    ).done(function ()
	    {
		mGeoApp.root.empty();
		mGeoApp.root.append('<mgeowrapper></mgeowrapper>');
		var elemInstance = document.getElementById('mgeowrapper');
		if (elemInstance) {
		    ko.components.register('mgeowrapper', {
			viewModel: function (params) {
			    var self = this;
			    mGeoApp.components.map = L.map('map', {zoomControl: false, closePopupOnClick: false}).setView([48.2000, 16.3667], 13)
			    mGeoApp.components.map.addControl(L.control.zoom({position: "topright"}));
			    L.tileLayer('http://otile1.mqcdn.com/tiles/1.0.0/osm/{z}/{x}/{y}.png', {
				attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors | Tiles Courtesy of <a href="http://www.mapquest.com/" target="_blank">MapQuest</a> <img src="http://developer.mapquest.com/content/osm/mq_logo.png">'
			    }).addTo(mGeoApp.components.map);
			    if (mGeoApp.config.search.result) {
				mGeoApp.setWaypoints(mGeoApp.config.search.result);
			    }
			},
			template: {element: elemInstance}
		    });
		}

		var elemInstance = document.getElementById('mgeofilter');
		if (elemInstance && (mGeoApp.config.config.config.showFilter == 1)) {
		    ko.components.register('mgeofilter', {
			viewModel: function (params) {
			    var self = this;

			    mGeoApp.getMyLocation();

			    self.searchword = ko.observable("");
			    if (mGeoApp.config.search.facet.isoDate) {
				self.dateMin = mGeoApp.config.search.facet ? ko.observable(Number(mGeoApp.config.search.facet.isoDate[0].key)) : ko.observable(1900);
				self.dateMax = mGeoApp.config.search.facet ? ko.observable(Number(jQuery(mGeoApp.config.search.facet.isoDate).last()[0].key)) : ko.observable(2015);
			    }
			    self.dateRangeMin = mGeoApp.config.config.dateRange.min;
			    self.dateRangeMax = mGeoApp.config.config.dateRange.max;


			    self.dateRange = ko.observable(self.dateMin() + "," + self.dateMax());
			    self.selectedTopics = ko.observableArray([]);
			    self.selectedPostalCode = ko.observable();


			    self.components = mGeoApp.components;
			    self.data = mGeoApp.data;


			    self.Topics = mGeoApp.data.search.Topics;


			    self.filter = mGeoApp.components.filter;
			    self.filterresult = mGeoApp.components.filterresult;
			    self.walks = mGeoApp.components.walks;

			    self.navItems = ko.observableArray(mGeoApp.config.config.navi);

			    self.showOverlay = function (data) {
				mGeoApp.showOverlay(data.uid);

			    }

			    self.showShareUrl = function () {

				mGeoApp.showOverlayWithContent(self.shareUrl(), 'shareUrl');
			    }


			    function deselectAllTopics() {
				var topics = [];

				jQuery.each(self.Topics(), function (key, value) {
				    self.Topics()[key].isChecked(false);
				});

			    }

			    function setTopics(swtGroup, selectedTopics) {


				jQuery.each(self.Topics(), function (key, value) {
				    var count = 0;
				    var curid = value.id();
				    var checked = false;
				    if (swtGroup) {
					jQuery.each(swtGroup, function (i, facet) {
					    if (String(curid) === String(facet.key)) {
						count = facet.value;
					    }
					});
				    }
				    if (selectedTopics) {
					jQuery.each(selectedTopics, function (i, topicid) {
					    if (String(curid) === String(topicid)) {
						checked = true;
					    }
					});
				    }
				    self.Topics()[key].count(count);
				    self.Topics()[key].isChecked(checked);
				});


			    }

			    function setSelectedTopic(selectedTopics) {

				if (selectedTopics) {
				    jQuery.each(selectedTopics, function (i, id) {
					self.selectedTopics().push(String(id));
				    });
				}
			    }

			    self.showMyLocation = function () {

				if (mGeoApp.data.mylocation()) {
				    if (mGeoApp.mapdata.mypositioncircle) {
					mGeoApp.components.map.removeLayer(mGeoApp.mapdata.mypositioncircle);
				    }

				    var radius = mGeoApp.data.mylocation().accuracy / 2;
				    var circle = L.circle(mGeoApp.data.mylocation().latlng, radius).addTo(mGeoApp.components.map);
				    mGeoApp.mapdata.mypositioncircle = circle.addTo(mGeoApp.components.map);

				    mGeoApp.components.map.fitBounds(circle.getBounds(), {maxZoom: 16});


				}
				mGeoApp.hideMeta();
				self.navIsHidden(true);

			    }


			    self.showShareUrlOverlay = ko.observable(false);
			    self.shareUrl = ko.observable("");

			    self.toggleShareUrlOverlay = function () {
				self.showShareUrlOverlay(!self.showShareUrlOverlay());
			    };


			    self.showResult = ko.observable(false);

			    self.dateTop = ko.computed(function () {
				var date = self.dateRange().split(",");
				return date[1];
			    });

			    self.dateBottom = ko.computed(function () {
				var date = self.dateRange().split(",");
				return date[0];
			    });


			    mGeoApp.components.filter.dateslider = jQuery("#ex2").slider({
				min: Number(self.dateRangeMin),
				max: Number(self.dateRangeMax),
				value: [Number(self.dateMin()), Number(self.dateMax())],
				step: 1,
				tooltip: 'always'
			    });


			    self.resetTopics = function () {
				deselectAllTopics();
			    }

			    self.showResetTopics = ko.computed(function () {
				var show = false;
				jQuery.each(self.Topics(), function (key, value) {
				    if (value.isChecked()) {
					show = true;
				    }

				});
				return show;

			    });
			    self.resetSearchWord = function () {
				self.searchword("");
			    }

			    self.resetDateRange = function () {
				self.dateRange(self.dateRangeMin + ',' + self.dateRangeMax);
				mGeoApp.components.filter.dateslider.attr("value", self.dateRangeMin + ',' + self.dateRangeMax);
				mGeoApp.components.filter.dateslider.slider('setValue', [Number(self.dateRangeMin), Number(self.dateRangeMax)]);
			    }


			    self.showResetDateRange = ko.computed(function () {
				var date = self.dateRange().split(",");
				if (Number(date[0]) != self.dateRangeMin || Number(date[1]) != self.dateRangeMax) {
				    return true;
				} else {
				    return false;
				}
			    });
			    self.resetPostalCode = function () {
				self.selectedPostalCode("");
			    }


			    self.showResetPostalCode = ko.computed(function () {
				if (self.selectedPostalCode()) {
				    return true;
				} else {
				    return false;
				}
			    });

			    self.resetFilter = function () {
				self.resetSearchWord();
				self.resetDateRange();
				self.resetTopics();
				self.resetPostalCode();
				self.SendForm();
				self.resetWalk();

				if (mGeoApp.mapdata.walk) {
				    mGeoApp.components.map.removeLayer(mGeoApp.mapdata.walk);
				}
				mGeoApp.showMeta();

			    }

			    self.resetWalk = function () {
				self.walkDescription('');
				self.walkDescriptionShort('');
				self.walkTitle('');
				self.selectedWalk('');

				if (mGeoApp.mapdata.walk) {
				    mGeoApp.components.map.removeLayer(mGeoApp.mapdata.walk);
				}
			    }

			    self.showResetSection = ko.computed(function () {
				if (self.selectedPostalCode() || self.showResetDateRange() || self.showResetTopics()) {
				    return true;
				} else {
				    return false;
				}
			    });




			    self.filter.isOpen = ko.observable(false);
			    self.walks.isOpen = ko.observable(false);
			    self.filterresult.isOpen = ko.observable(false);

			    mGeoApp.root.find('.collapseFilter-options').collapse({
				toggle: false
			    });


			    self.toggleFilter = function () {
				mGeoApp.root.find('.collapseFilter-options').collapse('toggle');
				self.filter.isOpen(!self.filter.isOpen());

				if (self.filter.isOpen()) {
				    self.hideWalks();
				    self.hideFilterresult();
				}
			    }

			    self.hideFilter = function () {
				mGeoApp.root.find('.collapseFilter-options').collapse('hide');
				self.filter.isOpen(false);
			    }

			    self.toggleFilterResult = function () {
				mGeoApp.root.find('.collapseFilter-result').collapse('toggle');
				self.filterresult.isOpen(!self.filterresult.isOpen());

				if (self.filterresult.isOpen()) {
				    self.hideWalks();
				    self.hideFilter();
				}
			    }


			    self.hideFilterresult = function () {
				mGeoApp.root.find('.collapseFilter-result').collapse('hide');
				self.filterresult.isOpen(false);
			    }


			    self.toggleWalks = function () {
				mGeoApp.root.find('.collapseFilter-walks').collapse('toggle');


				self.walks.isOpen(!self.walks.isOpen());
				if (self.walks.isOpen()) {
				    self.hideFilter();
				    self.hideFilterresult();
				}

			    }


			    self.hideWalks = function () {
				mGeoApp.root.find('.collapseFilter-walks').collapse('hide');
				self.walks.isOpen(false);
			    }



			    self.PostalCodes = mGeoApp.data.search.PostalCodes;

			    self.Walks = mGeoApp.data.search.Walks;
			    self.walkDescription = ko.observable('');
			    self.walkDescriptionShort = ko.observable('');
			    self.walkTitle = ko.observable('');
			    self.selectedWalk = ko.observable();



			    self.results = mGeoApp.data.waypoints;


			    function PostalCode(id, title, count) {
				this.id = id;
				this.title = title;
				this.count = ko.observable(count);
			    }


			    var listofPostalCodes = [];
			    if (mGeoApp.config.search.facet && mGeoApp.config.search.facet.PostalCode) {
				jQuery.each(mGeoApp.config.search.facet.PostalCode, function (i, facet) {
				    jQuery.each(mGeoApp.config.config.PostalCodes, function (key, value) {
					if (key === facet.key) {
					    listofPostalCodes.push(new PostalCode(key, value, facet.value));
					}
				    });
				});
			    } else {
				jQuery.each(mGeoApp.config.config.PostalCodes, function (key, value) {
				    listofPostalCodes.push(new PostalCode(key, value, 0));
				});
			    }

			    self.PostalCodes(listofPostalCodes);
			    function Topic(id, title, count, isChecked) {
				this.id = ko.observable(String(id));
				this.title = title;
				this.count = ko.observable(count);
				this.isChecked = ko.observable(isChecked);
			    }

			    var listOfTopics = [];
			    jQuery.each(mGeoApp.config.config.swtGroups, function (key, value) {
				var count = 0;
				var checked = false;
				if (mGeoApp.config.search.facet && mGeoApp.config.search.facet.swtGroup) {
				    jQuery.each(mGeoApp.config.search.facet.swtGroup, function (i, facet) {
					if (key === facet.key) {
					    //checked = true;
					    // self.selectedTopics().push(key);
					    count = facet.value;
					}

				    });
				}
				listOfTopics.push(new Topic(key, value, count, checked));
			    });
			    self.Topics(listOfTopics);
			    //selectAllTopics();

			    /*walks*/

			    function Walk(id, title, selected) {
				this.id = id;
				this.title = title;
				this.selected = selected
			    }





			    var listOfWalks = [];
			    $.when(
				    $.ajax({
					dataType: "json",
					url: mGeoApp.config.config.config.walkCall
				    })

				    ).done(function (walks)
			    {
				if (walks && walks.list) {
				    jQuery.each(walks.list, function (key, value) {
					listOfWalks.push(new Walk(value.uid, value.title));
				    });
				}

				self.Walks(listOfWalks);
			    });




			    self.navIsHidden = mGeoApp.components.filter.navIsHidden;


			    self.SearchisHidden = ko.observable(false);

			    self.toggleNav = function () {
				self.navIsHidden(!self.navIsHidden());

			    }

			    self.curWalk = ko.observable();

			    self.showWalk = function (data) {


				if (String(self.curWalk()) === String(data.id)) {
				    self.SendForm();
				    self.curWalk("");

				} else {


				    $.when(
					    $.ajax({
						dataType: "json",
						url: mGeoApp.config.config.config.walkCall + "/?params[walk]=" + data.id
					    })

					    ).done(function (walkdata)
				    {
					if (walkdata && walkdata.detail) {
					    self.walkDescription(walkdata.detail.longdesc);
					    self.walkDescriptionShort(walkdata.detail.introduction);
					    self.walkTitle(walkdata.detail.title);
					    mGeoApp.setWaypoints(walkdata.detail.it);
					    mGeoApp.setGpx(walkdata.detail.wp)
					    /*jQuery.each(walks.list, function (key, value) {
					     
					     listOfWalks.push(new Topic(value.uid, value.title, 0));
					     });*/
					}
				    });
				    self.curWalk(data.id);
				}


				return true;
			    }



			    /*./ walks*/
			    mGeoApp.root.find('.input-searchword').keypress(function (e) {
				if (e.which == 13) {
				    mGeoApp.root.find('form').submit();
				    return false;
				}
			    });




			    /*Set Filter*/
			    var filter = mGeoApp.config.search.filter;
			    if (mGeoApp.config.search) {
				self.searchword(mGeoApp.config.search.searchword);
			    }
			    if (filter) {

				var dateBottom = filter.date && filter.date.min ? filter.date.min : self.dateMin();
				var dateTop = filter.date && filter.date.max ? filter.date.max : self.dateMax();
				jQuery("#ex2").slider('setValue', [Number(dateBottom), Number(dateTop)]);


				if (filter.swtGroup) {
				    setTopics(mGeoApp.config.search.facet.swtGroup, filter.swtGroup);
				}

				if (filter.postalCode) {
				    self.selectedPostalCode(filter.postalCode);
				}
				if (mGeoApp.config.searchurl) {
				    self.shareUrl(mGeoApp.config.searchurl);
				}

			    }
			    /* ./ Set Filter*/




			    self.SendForm = function (data) {
				mGeoApp.tools.showLoader();
				self.resetWalk();
				mGeoApp.hideMeta();


				self.navIsHidden(true);


				var request = mGeoApp.urls.search.request;
				var date = (jQuery(mGeoApp.components.filter.dateslider).val()).split(",");
				var selectedTopics = [];

				jQuery.each(self.Topics(), function (key, value) {
				    if (value.isChecked()) {
					selectedTopics.push(value.id);
				    }
				});

				var p = {params: {
					searchword: self.searchword(),
					filter: {
					    swtGroup: selectedTopics,
					    date:
						    {
							min: date[0],
							max: date[1]
						    },
					    postalCode: self.selectedPostalCode(),
					}

				    }
				};




				//p.params.push({filter : filter});
				jQuery.post(request, p).done(function (response) {
				    //do something
				    if (response && response.result) {

					mGeoApp.setWaypoints(response.result);
					setTopics(response.facet.swtGroup, response.filter.swtGroup);
					//setSelectedTopic(response.filter.swtGroup);
					self.shareUrl(response.searchurl);

					if (response.filter.date && response.filter.date.min && response.filter.date.max) {
					    var first = response.filter.date.min;
					    var last = response.filter.date.max;

					    jQuery("#ex2").slider('setValue', [Number(first), Number(last)]);
//											jQuery("#ex2").slider.setAttribute('min', first).refresh();
//											jQuery("#ex2").slider.setAttribute('max', last).refresh();
					    //mGeoApp.components.filter.dateslide.slider.setAttribute('max', last).refresh();		
					}






				    } else if (response && !response.result) {
					mGeoApp.setWaypoints([]);
					self.shareUrl(response.searchurl);
				    }

				    //todo fehlerbehandlung
				    mGeoApp.tools.hideLoader();
				});
			    }


			    self.focusMarker = function (data) {
				self.navIsHidden(true);
				//openMarkerPopup(data.UniqueIdentifier);
				mGeoApp.openMarkerPopup(data.UniqueIdentifier);




			    }

			    mGeoApp.tools.initScroller('.mgeo-scrollable');
			},
			template: {element: elemInstance}

		    });
		}

		var mapmodel = {};
		ko.applyBindings(mapmodel, document.getElementsByTagName("mgeowrapper")[0]);
	    });
	},
	clearLayers: function () {
	    if (mGeoApp.mapdata && mGeoApp.mapdata.layerGroups && mGeoApp.mapdata.layerGroups().length > 0) {
		$.each(mGeoApp.mapdata.layerGroups(), function (key, value) {
		    value.clearLayers();
		});
	    }
	},
	tools: {
	    //Initialisiert den JqueryScroller
	    initScroller: function (selector) {
		jQuery(selector).jScrollPane({
		    autoReinitialise: true,
		    verticalDragMinHeight: 45

		});


	    },
	    //Lädt Scripte
	    loadScripts: function (scriptPaths, callback) {
		var progress = 0;
		var internalCallback = function () {
		    if (++progress == scriptPaths.length) {
			callback();
		    }
		};
		scriptPaths.forEach(function (script) {
		    $.getScript(script, internalCallback);
		});
	    },
	    //Fügt CSS in das DOM Element Head ein
	    loadCss: function (cssPaths) {

		cssPaths.forEach(function (item) {
		    $("<link/>", {
			rel: "stylesheet",
			type: "text/css",
			href: item
		    }).appendTo("head");
		});
	    },
	    setDivPosition: function (yTarget, yEvent, yParent, yCloseButton) {
		var info = $(yTarget);
		if (yCloseButton) {
		    info.find(yCloseButton)
			    .off("click")
			    .on("click", function (event) {
				info.hide();
			    });
		}
		var src = $(yEvent.target);
		var cWidth = $(yParent).width();
		//var cHeight = $(yParent).height();
		var cHeight = $(yParent)[0].scrollHeight;
		var targetX = src.position().left - info.width();
		var targetY = src.position().top;
		//var targetY = 0;
		if (targetX + info.width() > cWidth) {
		    targetX += cWidth - (targetX + info.width());
		} else if (targetX < 0) {
		    targetX = 0;
		}



		if (info.height() >= cHeight) {
		    targetY = 0;
		} else if (targetY + info.height() > cHeight) {
		    targetY += cHeight - (targetY + info.height());
		} else if (targetY < 0) {
		    targetY = 0;
		}

		if (cHeight < info.height()) {
		    targetY += ($(yParent).height() - info.height());
		}

		info.css('left', targetX + 'px')
			.css('top', targetY + 'px');
		// info.show();

		return 0;
	    },
	    //Liest den Dateityp einer Datei anhand der Dateiendung aus
	    getFileExtension: function (url) {


		url = url.substring(0, (url.indexOf("#") == -1) ? url.length : url.indexOf("#"));
		url = url.substring(0, (url.indexOf("?") == -1) ? url.length : url.indexOf("?"));
		url = url.substring(url.lastIndexOf("/") + 1, url.length);
		url = (/[.]/.exec(url)) ? /[^.]+$/.exec(url) : undefined;
		if (url) {
		    return url[0];
		}

		return url;
	    },
	    //Erkennt op es sich um ein Mobilgerät handelt
	    isMobile: function () {
		var check = false;
		(function (a) {
		    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
			check = true
		})(navigator.userAgent || navigator.vendor || window.opera);
		mGeoApp.isMobile = check;
	    },
	    //Zeigt den Ladeicon an
	    showLoader: function () {
		jQuery('.mgeo-loader-wrapper').show();
	    },
	    //Blendet den Ladeicon aus
	    hideLoader: function () {
		jQuery('.mgeo-loader-wrapper').hide();
	    }
	},
	showOverlayFromUrl: function (url, id) {

	    var target = jQuery(".mgeo-overlay-scrollerwrap");

	    if (!target.length) {
		jQuery('body').append('<div style="display:none" class="mgeo-overlay-wrapper mgeo-overlay-scrollerwrap"> <div class="mgeo-overlay"><div class="mgeo-overlay-close"></div><div class="mgeo-scrollable"><div class="mgeo-overlay-content"><div></div></div></div><\/div></div>');
		target = jQuery(".mgeo-overlay-scrollerwrap");
	    }
	    target.attr("id", "overlay_" + id);


	    target.find(".mgeo-overlay-close")
		    .off("click")
		    .on("click", function (event) {
			target.hide();
		    });

	    var tcontent = target.find(".mgeo-overlay-content");

	    tcontent.load(url + " .inhalt_lightbox", function (response, status, xhr) {
		target.show();
		mGeoApp.tools.initScroller('.mgeo-scrollable');

	    });

	},
	//Öffnet ein Overlay und befüllt es mit dem übergebenen Inhalt
	showOverlayWithContent: function (content, id) {
	    var target = jQuery(".mgeo-overlay-wrapper");

	    if (!target.length) {
		jQuery('body').append('<div style="display:none" class="mgeo-overlay-wrapper"> <div class="mgeo-overlay"><div class="mgeo-overlay-close"></div><div class="mgeo-scrollable"><div class="mgeo-overlay-content"><div></div></div></div><\/div></div>');
		target = jQuery(".mgeo-overlay-wrapper");
	    }
	    target.attr("id", id);


	    target.find(".mgeo-overlay-close")
		    .off("click")
		    .on("click", function (event) {
			target.hide();
		    });

	    var tcontent = target.find(".mgeo-overlay-content");
	    tcontent.html(content);
	    target.show();

	},
	//Versteckt die MetaNavigation
	hideMeta: function () {
	    jQuery('#header').addClass("hidden-xs");
	    jQuery('#footer').addClass("hidden-xs");
	    jQuery('#content').addClass("mgeo-fullheight");

	},
	//Zeit die MetaNavigation an
	showMeta: function () {
	    jQuery('#header').removeClass("hidden-xs");
	    jQuery('#footer').removeClass("hidden-xs");
	    jQuery('#content').removeClass("mgeo-fullheight");
	},
	//Öffnet ein Overlay
	showOverlay: function (id, name) {
	    var pages = mGeoApp.config.config.navi;
	    var curpage = "";
	    var curid = "";
	    if (pages) {

		jQuery.each(pages, function (key, value) {

		    if (value && value.uid == id) {
			curpage = value;
		    }
		});

		var url = mGeoApp.config.config.config.contentUrl + curpage.uid;

		mGeoApp.showOverlayFromUrl(url, id);

	    }
	}
    };
})(jQuery);


$(function () {
    var initConfig = {
	url: ajaxUrl + '/type/geodata/gateway/init/call/run'
    };

    //init Map
    mGeoApp.initMap(initConfig);

    //Browserback support
    (function (window, undefined) {

	// Bind to StateChange Event
	History.Adapter.bind(window, 'statechange', function () { // Note: We are using statechange instead of popstate
	    var State = History.getState(); // Note: We are using History.getState() instead of event.state

	    setContent(State);

	});


	function setContent(State) {
	    if (State && State.data && State.data.state != "Player") {
		var atomid = State.data && State.data.atomid ? State.date.atomid : "";
		mGeoApp.closePlayer(atomid);
		//window.history.replaceState({}, 'foo', '');
	    }

	    if (State && State.data && State.data.state == "Player" && State.data.atomid) {
		var atomid = State.data.atomid;
		mGeoApp.closePlayer(atomid);
		mGeoApp.setPlayer(atomid);
		mGeoApp.openMarkerPopup(atomid);
		mGeoApp.components.filter.navIsHidden(true);
	    }
	}

    })(window);

});
//# sourceURL=mapmanger.js